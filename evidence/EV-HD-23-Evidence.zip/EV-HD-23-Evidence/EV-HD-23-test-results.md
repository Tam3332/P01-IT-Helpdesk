# EV-HD-23 — IA-HD03 Secure File Upload Test Results

## Environment
- Platform: Ubuntu VirtualBox VM
- Backend: Deployed via Docker (p01-backend, p01-gateway)
- Execution status: EXECUTED - TC01 to TC21 (including backend log scan) (see detailed evidence)

## Test Results

| Test Case | Scenario | Expected Result | Actual Result | Status |
|---|---|---|---|---|
| SEC-TC-HD-03.1 | Valid file upload | Accepted if authorized | TC12: authorized TXT upload returned HTTP 201; attachment ID 9 created; storage verified | PASS |
| SEC-TC-HD-03.1 | Invalid extension | HTTP 400, no storage | TC17: invalid.exe rejected with FILE_TYPE_NOT_ALLOWED; no corresponding new file found in ticket 7 storage | PASS |
| SEC-TC-HD-03.1 | MIME/signature mismatch | HTTP 400, no storage | TC01 and TC05: backend returned FILE_TYPE_NOT_ALLOWED; HTTP status and storage outcome not independently verified | PARTIAL PASS |
| SEC-TC-HD-03.2 | File over 10 MB | HTTP 400, no storage | TC02: backend returned FILE_TOO_LARGE; TC03: Nginx returned HTTP 413; backend HTTP status and storage outcome not independently verified | PARTIAL PASS |
| SEC-TC-HD-03.2 | Sixth attachment | HTTP 400, no storage | Backend returned ATTACHMENT_LIMIT_EXCEEDED; HTTP status and storage outcome not independently verified | PARTIAL PASS |
| SEC-TC-HD-03.3 | Filename/path traversal | Cannot escape allowed storage | Upload succeeded; file stored using UUID filename in inspected storage directory; traversal escape not fully verified | PARTIAL PASS |
| SEC-TC-HD-03.4 | Authorized download | File delivered | TC18: HTTP 200; attachment ID 9 downloaded successfully; content verified; SHA-256 recorded | PASS |
| SEC-TC-HD-03.4 | Unauthorized download | HTTP 403 or 404 per access scope | TC09: admin returned FORBIDDEN; employee2 and staff2 returned TICKET_NOT_FOUND; HTTP status not independently verified | PARTIAL PASS |
| SEC-TC-HD-03.4 | Wrong ticket attachment | HTTP 404 | TC16: cross-user ticket access returned HTTP 404; attachment ID belonging to another ticket not specifically tested | NOT RUN |
| SEC-TC-HD-03.5 | Upload to Closed ticket | HTTP 422 | TC20: upload to HD-2026-0005 (CLOSED) returned HTTP 422, error TICKET_CLOSED | PASS |
| SEC-TC-HD-03.5 | Sensitive data in logs | No password/JWT exposure | Scanned /app/logs/audit_events.jsonl; no password, token, Bearer or JWT patterns detected using defined regex | PASS |

## Test Data

- test-data/ia-hd03/valid.txt
- test-data/ia-hd03/fake.pdf
- test-data/ia-hd03/invalid.exe
- test-data/ia-hd03/over-10mb.txt

## Pending Dependencies

- Wrong ticket attachment ID pairing within the same authorized scope remains unverified.
- Additional MIME/signature, oversized-file and storage verification is needed to upgrade PARTIAL PASS results.
- Log scan used defined patterns only; it does not prove the absence of every possible sensitive-data format.

## Conclusion

IA-HD03 test cases and sample test data are prepared.
Backend security tests TC01-TC20 and a backend log scan have been executed. Results and limitations are documented in this report.

## Actual Execution Results — TC01 to TC16

Environment: Ubuntu VirtualBox, Docker backend, HTTPS gateway port 8443.

| Test Case | Scenario | Actual Result | Status |
|---|---|---|---|
| TC01 | Fake JPG / invalid content | Rejected with FILE_TYPE_NOT_ALLOWED | PARTIAL PASS |
| TC02 | 10.5 MB file | Backend returned FILE_TOO_LARGE; HTTP/storage not independently verified | PARTIAL PASS |
| TC03 | Oversized request via Nginx | Rejected by gateway | PASS |
| TC04 | Attachment limit test | ATTACHMENT_LIMIT_EXCEEDED; HTTP/storage not independently verified | PARTIAL PASS |
| TC05 | MIME mismatch | FILE_TYPE_NOT_ALLOWED; HTTP/storage not independently verified | PARTIAL PASS |
| TC06 | SVG upload | Rejected | PASS |
| TC07 | Empty file | Rejected | PASS |
| TC08 | Path traversal filename | UUID storage observed; traversal escape not fully verified | PARTIAL PASS |
| TC09 | Unauthorized access checks | Denial responses collected; HTTP status not independently verified | PARTIAL PASS |
| TC10 | PHP content disguised as JPG | HTTP 400, FILE_TYPE_NOT_ALLOWED | PASS |
| TC11 | HTML content disguised as JPG | HTTP 400, FILE_TYPE_NOT_ALLOWED | PASS |
| TC12 | Special characters in filename | HTTP 201; metadata preserved; UUID storage confirmed | PASS |
| TC13 | SVG containing JavaScript | HTTP 400, FILE_TYPE_NOT_ALLOWED | PASS |
| TC14 | Direct static URL without authentication | HTTP 200 frontend fallback; attachment content not returned | PASS (tested URL only) |
| TC15 | Attachment list without authentication | HTTP 401, UNAUTHORIZED | PASS |
| TC16 | Cross-user ticket and attachment access | HTTP 404, TICKET_NOT_FOUND; target absent from employee2 ticket list | PASS (tested accounts/ticket) |

| TC17 | Invalid extension (.exe) | HTTP 400, FILE_TYPE_NOT_ALLOWED; no corresponding new file found | PASS |
| TC18 | Authorized download | HTTP 200; downloaded content verified; SHA-256 recorded | PASS |
| TC19 | Cross-user attachment download | HTTP 404, TICKET_NOT_FOUND; cross-user denial verified | PASS (tested scope only) |
| TC20 | Upload to Closed ticket | HTTP 422, TICKET_CLOSED | PASS |
| TC21 | Sensitive data in backend logs | One audit log scanned; no defined password/JWT/Bearer patterns detected | PASS (tested patterns only) |

## Evidence Package

- Archive: EV-HD-23_security_evidence_v2.zip
- Evidence files: 29
- Credential-bearing login response files excluded.
- Filename and content pattern checks found no matching common token/password patterns.

## Limitations and Follow-up

- TC14 verifies only the specific static URL tested; HTTP 200 returned the frontend fallback page.
- TC16 verifies cross-user access for employee2 (ID 6) against ticket HD-2026-0007 (requester ID 1).
- TC17-TC20 provide additional evidence for invalid extension, authorized download, cross-user access and closed-ticket upload.
- TC19 verifies cross-user denial, not a mismatched ticket/attachment ID pair within the same authorized scope.
- The log scan covered one file and defined patterns only.
- Five requirements remain PARTIAL PASS and one requirement remains NOT RUN.
